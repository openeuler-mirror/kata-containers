# RateLimiterConfig

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Bandwidth** | [**TokenBucket**](TokenBucket.md) |  | [optional] 
**Ops** | [**TokenBucket**](TokenBucket.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


