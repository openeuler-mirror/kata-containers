[![Build Status](https://travis-ci.org/kata-containers/proxy.svg?branch=master)](https://travis-ci.org/kata-containers/proxy)
[![codecov](https://codecov.io/gh/kata-containers/proxy/branch/master/graph/badge.svg)](https://codecov.io/gh/kata-containers/proxy)

# Kata Containers Proxy

The `kata-proxy` is part of the Kata Containers project. For more information on how
the `proxy` fits into the Kata Containers architecture, refer to the
[Kata Containers architecture documentation](https://github.com/kata-containers/documentation/blob/master/design/architecture.md#proxy).
