# PmemConfig

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**File** | **string** |  | 
**Size** | **int64** |  | [optional] 
**Iommu** | **bool** |  | [optional] [default to false]
**Mergeable** | **bool** |  | [optional] [default to false]
**DiscardWrites** | **bool** |  | [optional] [default to false]
**Id** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


