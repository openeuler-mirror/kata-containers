# Cloud Hypervisor OpenAPI generated code

This directory provide tools to generate code client based
on `cloud-hypervisor` `OpenAPI` schema.

## Update client to match latest Cloud Hypervisor server API

Requirements:
 - docker: `openapi-generator` is executed in a docker container

```
make all
```
