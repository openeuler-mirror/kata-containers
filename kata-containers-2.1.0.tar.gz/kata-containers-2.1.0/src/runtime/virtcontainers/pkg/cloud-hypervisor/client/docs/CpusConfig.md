# CpusConfig

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**BootVcpus** | **int32** |  | [default to 1]
**MaxVcpus** | **int32** |  | [default to 1]
**Topology** | [**CpuTopology**](CpuTopology.md) |  | [optional] 
**MaxPhysBits** | **int32** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


