//
// Copyright 2017 HyperHQ Inc.
//
// SPDX-License-Identifier: Apache-2.0
//

package grpc

// APIVersion specifies the version of the gRPC communications protocol used
// by Kata Containers.
const APIVersion = "0.0.1"
