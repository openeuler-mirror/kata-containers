This package is a simple placeholder currently which will contain persist storage plugin support,
e.g. LevelDB, SQLite and other possible storage implementations.
