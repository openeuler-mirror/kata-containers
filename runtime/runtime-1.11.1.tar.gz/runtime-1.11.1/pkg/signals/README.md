# Signals package

The `signals` package contains common signal handling functions that are shared by
the binaries built in this repository.
