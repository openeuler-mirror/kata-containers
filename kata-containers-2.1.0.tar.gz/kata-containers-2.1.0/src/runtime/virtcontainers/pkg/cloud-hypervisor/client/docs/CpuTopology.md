# CpuTopology

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ThreadsPerCore** | **int32** |  | [optional] 
**CoresPerDie** | **int32** |  | [optional] 
**DiesPerPackage** | **int32** |  | [optional] 
**Packages** | **int32** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


