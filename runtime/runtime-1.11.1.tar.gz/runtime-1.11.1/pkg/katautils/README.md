# Kata utilities packages

The `katautils` package contains useful functions that are shared by various
parts of the codebase, including the runtime and the container v2 shim.
