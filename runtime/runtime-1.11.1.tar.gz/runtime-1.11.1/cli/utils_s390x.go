// Copyright (c) 2018 IBM
//
// SPDX-License-Identifier: Apache-2.0
//

package main

func archConvertStatFs(cgroupFsType int) uint32 {
	return uint32(cgroupFsType)
}
