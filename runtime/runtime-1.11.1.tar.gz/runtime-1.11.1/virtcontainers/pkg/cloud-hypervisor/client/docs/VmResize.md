# VmResize

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**DesiredVcpus** | **int32** |  | [optional] 
**DesiredRam** | **int64** | desired memory ram in bytes | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


