# Kata Containers E2E Flow


![Kata containers e2e flow](arch-images/katacontainers-e2e-with-bg.jpg)
